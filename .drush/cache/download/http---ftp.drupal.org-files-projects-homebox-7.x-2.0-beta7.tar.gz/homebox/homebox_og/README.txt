
Homebox 2 can integrate with the Organic Groups module.

Please read the relevant section in the main README.txt, located in the
module root.
