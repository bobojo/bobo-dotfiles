<?php print $platon__header; ?>
<?php print $platon__site_content; ?>
<?php print $platon__footer; ?>
