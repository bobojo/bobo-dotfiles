<?php if (!empty($page['footer'])): ?>
  <footer id="site-footer">
    <div class="row">
      <div class="col span_6">
        <?php print render($page['footer']); ?>
      </div>
    </div>
  </footer>
<?php endif; ?>
