<div class="row">
  <?php foreach ($items as $item): ?>
    <div class="col col-1-out-of-2 col-2-out-of-4 col-2-out-of-6">
      <?php print $item; ?>
    </div>
  <?php endforeach; ?>
</div>
