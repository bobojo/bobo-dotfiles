<div id="site-content">
  <div class="row">
    <?php print $platon__site_content__first_sidebar; ?>
    <?php print $platon__site_content__second_sidebar; ?>
  </div>
</div>
