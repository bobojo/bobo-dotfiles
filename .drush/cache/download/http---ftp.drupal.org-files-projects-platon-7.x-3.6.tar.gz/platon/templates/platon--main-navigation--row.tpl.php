<div class="row main-navigation-row">
  <?php print $items; ?>
</div>