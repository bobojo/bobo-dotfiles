
ORGANIC GROUPS MASS ADD

A module for mass-adding users to an organic group (and Drupal, if necessary).

Developed by the Norwegian Center for integrated care and Telemedicine.

REQUIREMENTS

- Organic Groups
- Content Profile

HOW TO INSTALL

1. Upload and extract to your modules directory as a normal Drupal module.
2. Enable the module

HOW TO USE

To be written...

OTHER STUFF

To be written...
